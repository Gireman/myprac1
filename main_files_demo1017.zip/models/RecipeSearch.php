<?php

namespace app\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Recipe;

/**
 * RecipeSearch represents the model behind the search form of `app\models\Recipe`.
 */
class RecipeSearch extends Recipe
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id', 'id_method', 'card_minutes', 'taste_acidity', 'taste_body', 'taste_sweetness', 'has_milk', 'taste_minutes'], 'integer'],
            [['title', 'level', 'roast', 'description', 'img', 'img_alt', 'pill_color', 'fact_coffee', 'fact_water', 'fact_time', 'tip'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Recipe::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'id_method' => $this->id_method,
            'card_minutes' => $this->card_minutes,
            'taste_acidity' => $this->taste_acidity,
            'taste_body' => $this->taste_body,
            'taste_sweetness' => $this->taste_sweetness,
            'has_milk' => $this->has_milk,
            'taste_minutes' => $this->taste_minutes,
        ]);

        $query->andFilterWhere(['like', 'title', $this->title])
            ->andFilterWhere(['like', 'level', $this->level])
            ->andFilterWhere(['like', 'roast', $this->roast])
            ->andFilterWhere(['like', 'description', $this->description])
            ->andFilterWhere(['like', 'img', $this->img])
            ->andFilterWhere(['like', 'img_alt', $this->img_alt])
            ->andFilterWhere(['like', 'pill_color', $this->pill_color])
            ->andFilterWhere(['like', 'fact_coffee', $this->fact_coffee])
            ->andFilterWhere(['like', 'fact_water', $this->fact_water])
            ->andFilterWhere(['like', 'fact_time', $this->fact_time])
            ->andFilterWhere(['like', 'tip', $this->tip]);

        return $dataProvider;
    }
}
