<?php

namespace app\models;

use Yii;
use yii\helpers\ArrayHelper;

/**
 * This is the model class for table "recipe".
 *
 * @property int $id
 * @property string $title
 * @property int $id_method
 * @property string $level
 * @property string $roast
 * @property string $description
 * @property int $card_minutes
 * @property string $img
 * @property string $img_alt
 * @property string $pill_color
 * @property string $fact_coffee
 * @property string $fact_water
 * @property string $fact_time
 * @property string $tip
 * @property int $taste_acidity
 * @property int $taste_body
 * @property int $taste_sweetness
 * @property int $has_milk
 * @property int $taste_minutes
 *
 * @property Favourite[] $favourites
 * @property Method $method
 * @property RecipeEquipment[] $recipeEquipments
 * @property RecipeNote[] $recipeNotes
 * @property RecipeStep[] $recipeSteps
 */
class Recipe extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'recipe';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['title', 'id_method', 'level', 'roast', 'description', 'card_minutes', 'img', 'img_alt', 'pill_color', 'fact_coffee', 'fact_water', 'fact_time', 'tip', 'taste_acidity', 'taste_body', 'taste_sweetness', 'has_milk', 'taste_minutes'], 'required'],
            [['id_method', 'card_minutes', 'taste_acidity', 'taste_body', 'taste_sweetness', 'has_milk', 'taste_minutes'], 'integer'],
            [['level'], 'string'],
            [['title', 'roast', 'description', 'img', 'img_alt', 'pill_color', 'fact_coffee', 'fact_water', 'fact_time', 'tip'], 'string', 'max' => 255],
            [['id_method'], 'exist', 'skipOnError' => true, 'targetClass' => Method::className(), 'targetAttribute' => ['id_method' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'title' => 'Title',
            'id_method' => 'Id Method',
            'level' => 'Level',
            'roast' => 'Roast',
            'description' => 'Description',
            'card_minutes' => 'Card Minutes',
            'img' => 'Img',
            'img_alt' => 'Img Alt',
            'pill_color' => 'Pill Color',
            'fact_coffee' => 'Fact Coffee',
            'fact_water' => 'Fact Water',
            'fact_time' => 'Fact Time',
            'tip' => 'Tip',
            'taste_acidity' => 'Taste Acidity',
            'taste_body' => 'Taste Body',
            'taste_sweetness' => 'Taste Sweetness',
            'has_milk' => 'Has Milk',
            'taste_minutes' => 'Taste Minutes',
        ];
    }

    /**
     * Gets query for [[Favourites]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getFavourites()
    {
        return $this->hasMany(Favourite::className(), ['id_recipe' => 'id']);
    }

    /**
     * Gets query for [[Method]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getMethod()
    {
        return $this->hasOne(Method::className(), ['id' => 'id_method']);
    }

    /**
     * Gets query for [[RecipeEquipments]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getRecipeEquipments()
    {
        return $this->hasMany(RecipeEquipment::className(), ['id_recipe' => 'id']);
    }

    /**
     * Gets query for [[RecipeNotes]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getRecipeNotes()
    {
        return $this->hasMany(RecipeNote::className(), ['id_recipe' => 'id']);
    }

    /**
     * Gets query for [[RecipeSteps]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getRecipeSteps()
    {
        return $this->hasMany(RecipeStep::className(), ['id_recipe' => 'id'])->orderBy(['position' => SORT_ASC]);
    }

    /**
     * Ноты рецепта через связку recipe_note.
     *
     * @return \yii\db\ActiveQuery
     */
    public function getNotes()
    {
        return $this->hasMany(Note::class, ['id' => 'id_note'])->via('recipeNotes')->orderBy(['note.id' => SORT_ASC]);
    }

    /**
     * Оборудование рецепта через связку recipe_equipment.
     *
     * @return \yii\db\ActiveQuery
     */
    public function getEquipments()
    {
        return $this->hasMany(Equipment::class, ['id' => 'id_equipment'])->via('recipeEquipments')->orderBy(['equipment.id' => SORT_ASC]);
    }

    /**
     * Названия нот массивом: ['Цитрус', 'жасмин', 'мёд'].
     *
     * @return string[]
     */
    public function getNoteTitles()
    {
        return ArrayHelper::getColumn($this->notes, 'title');
    }

    /**
     * Размеры картинки [width, height] — в БД их нет, берём из файла.
     * Нужны для width/height у <img>, чтобы страница не прыгала при загрузке.
     *
     * @param int $width
     * @return int[]
     */
    public function getImgSize($width = 800)
    {
        $path = Yii::getAlias('@webroot/img/' . $this->img . '-' . $width . '.jpg');
        $size = is_file($path) ? @getimagesize($path) : false;
        return $size ? [(int)$size[0], (int)$size[1]] : [800, 600];
    }
}