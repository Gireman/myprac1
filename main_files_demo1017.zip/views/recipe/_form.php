<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Recipe */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="recipe-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'title')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'id_method')->textInput() ?>

    <?= $form->field($model, 'level')->dropDownList([ 'Легко' => 'Легко', 'Средне' => 'Средне', 'Точно' => 'Точно', ], ['prompt' => '']) ?>

    <?= $form->field($model, 'roast')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'description')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'card_minutes')->textInput() ?>

    <?= $form->field($model, 'img')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'img_alt')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'pill_color')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'fact_coffee')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'fact_water')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'fact_time')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'tip')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'taste_acidity')->textInput() ?>

    <?= $form->field($model, 'taste_body')->textInput() ?>

    <?= $form->field($model, 'taste_sweetness')->textInput() ?>

    <?= $form->field($model, 'has_milk')->textInput() ?>

    <?= $form->field($model, 'taste_minutes')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
