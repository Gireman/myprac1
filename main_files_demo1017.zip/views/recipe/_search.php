<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\RecipeSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="recipe-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'id') ?>

    <?= $form->field($model, 'title') ?>

    <?= $form->field($model, 'id_method') ?>

    <?= $form->field($model, 'level') ?>

    <?= $form->field($model, 'roast') ?>

    <?php // echo $form->field($model, 'description') ?>

    <?php // echo $form->field($model, 'card_minutes') ?>

    <?php // echo $form->field($model, 'img') ?>

    <?php // echo $form->field($model, 'img_alt') ?>

    <?php // echo $form->field($model, 'pill_color') ?>

    <?php // echo $form->field($model, 'fact_coffee') ?>

    <?php // echo $form->field($model, 'fact_water') ?>

    <?php // echo $form->field($model, 'fact_time') ?>

    <?php // echo $form->field($model, 'tip') ?>

    <?php // echo $form->field($model, 'taste_acidity') ?>

    <?php // echo $form->field($model, 'taste_body') ?>

    <?php // echo $form->field($model, 'taste_sweetness') ?>

    <?php // echo $form->field($model, 'has_milk') ?>

    <?php // echo $form->field($model, 'taste_minutes') ?>

    <div class="form-group">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-outline-secondary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
