<?php

/* @var $this yii\web\View */
/* @var $name string */
/* @var $message string */
/* @var $exception Exception */

use yii\helpers\Html;

$this->title = $name;
?>
<div class="site-error">

    <h1>404</h1>

    <p>
        <h2>Страница не найдена(</h2>  
    </p>
</div>
