<main id="main" class="matcher-page container">
  <div id="matcher-start">
    <section class="matcher-intro" aria-labelledby="matcher-title">
      <div>
        <p class="eyebrow">Персональный подбор</p>
        <h1 id="matcher-title">Какой кофе<br><em>подходит вам?</em></h1>
      </div>
      <p>Нет правильных и неправильных ответов. Выбирайте то, что ближе — и мы найдём ваш рецепт.</p>
    </section>
    <form class="matcher-form" id="matcher-form" aria-label="Тест вкусовых предпочтений">
        <fieldset class="question">
          <legend><span>01</span>Какое настроение хочется поймать?</legend><br>
          <div class="choice-group">
            <label class="choice">
              <input type="radio" name="mood" value="Легко и свежо" checked>
              <span class="choice-box"><span class="choice-mark"><svg class="icon" width="16" height="16" aria-hidden="true" focusable="false"><use href="#i-check"></use></svg></span>Легко и свежо</span>
            </label>
            <label class="choice">
              <input type="radio" name="mood" value="Мягко и уютно">
              <span class="choice-box"><span class="choice-mark"><svg class="icon" width="16" height="16" aria-hidden="true" focusable="false"><use href="#i-check"></use></svg></span>Мягко и уютно</span>
            </label>
            <label class="choice">
              <input type="radio" name="mood" value="Бодро и насыщенно">
              <span class="choice-box"><span class="choice-mark"><svg class="icon" width="16" height="16" aria-hidden="true" focusable="false"><use href="#i-check"></use></svg></span>Бодро и насыщенно</span>
            </label>
          </div>
        </fieldset>
        <fieldset class="question">
          <legend><span>02</span>Как вы обычно пьёте кофе?</legend><br>
          <div class="choice-group">
            <label class="choice">
              <input type="radio" name="format" value="Чистый кофе" checked>
              <span class="choice-box"><span class="choice-mark"><svg class="icon" width="16" height="16" aria-hidden="true" focusable="false"><use href="#i-check"></use></svg></span>Чистый кофе</span>
            </label>
            <label class="choice">
              <input type="radio" name="format" value="С молоком">
              <span class="choice-box"><span class="choice-mark"><svg class="icon" width="16" height="16" aria-hidden="true" focusable="false"><use href="#i-check"></use></svg></span>С молоком</span>
            </label>
            <label class="choice">
              <input type="radio" name="format" value="По-разному">
              <span class="choice-box"><span class="choice-mark"><svg class="icon" width="16" height="16" aria-hidden="true" focusable="false"><use href="#i-check"></use></svg></span>По-разному</span>
            </label>
          </div>
        </fieldset>
        <fieldset class="question">
          <legend><span>03</span>Сколько времени готовы уделить?</legend><br>
          <div class="choice-group">
            <label class="choice">
              <input type="radio" name="effort" value="До 2 минут">
              <span class="choice-box"><span class="choice-mark"><svg class="icon" width="16" height="16" aria-hidden="true" focusable="false"><use href="#i-check"></use></svg></span>До 2 минут</span>
            </label>
            <label class="choice">
              <input type="radio" name="effort" value="5 минут" checked>
              <span class="choice-box"><span class="choice-mark"><svg class="icon" width="16" height="16" aria-hidden="true" focusable="false"><use href="#i-check"></use></svg></span>5 минут</span>
            </label>
            <label class="choice">
              <input type="radio" name="effort" value="Можно не спешить">
              <span class="choice-box"><span class="choice-mark"><svg class="icon" width="16" height="16" aria-hidden="true" focusable="false"><use href="#i-check"></use></svg></span>Можно не спешить</span>
            </label>
          </div>
        </fieldset>
        <fieldset class="question">
          <legend><span>04</span>Как относитесь к кислинке?</legend><br><br>
          <div class="range-wrap">
            <label class="visually-hidden" for="acidity">Любовь к кислинке: от «Не люблю» до «Обожаю»</label>
            <input id="acidity" name="acidity" type="range" min="0" max="100" value="65">
            <div class="range-scale" aria-hidden="true"><span>Не люблю</span><span>Обожаю</span></div>
          </div>
        </fieldset>
        <button class="primary-button submit-match" type="submit">Показать мой профиль <svg class="icon" width="20" height="20" aria-hidden="true" focusable="false"><use href="#i-arrow"></use></svg></button>
    </form>
  </div>
  <section id="matcher-result" aria-label="Результат подбора" hidden></section>
</main>