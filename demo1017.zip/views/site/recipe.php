<main id="main" class="detail-page">
  <div id="recipe-root">
    <noscript><p class="noscript-note container">Для просмотра рецепта нужен включённый JavaScript. <a href="recipes">Вернуться к каталогу</a></p></noscript>
  </div>
</main>