<?php use yii\helpers\Url; ?>
  <main id="main" class="inner-page">
  <section class="page-heading container" aria-labelledby="catalog-title">
    <p class="eyebrow">36 рецептов · 8 методов</p>
    <h1 id="catalog-title">Ваша следующая<br><em>идеальная чашка</em></h1>
    <p class="page-lead">От короткого эспрессо до неспешного пуровера. Фильтруйте по способу и сохраняйте любимое.</p>
  </section>

  <section class="catalog-toolbar" aria-label="Поиск и фильтры">
    <div class="catalog-toolbar-inner container">
      <div class="search-box">
        <svg class="icon" width="20" height="20" aria-hidden="true" focusable="false"><use href="#i-search"></use></svg>
        <label class="visually-hidden" for="recipe-search">Найти рецепт или ноту</label>
        <input id="recipe-search" type="search" placeholder="Найти рецепт или ноту" autocomplete="off">
      </div>
      <div class="filters" role="group" aria-label="Способ заваривания">
        <button type="button" class="active" aria-pressed="true" data-filter="Все">Все</button>
        <button type="button" aria-pressed="false" data-filter="Пуровер">Пуровер</button>
        <button type="button" aria-pressed="false" data-filter="Эспрессо">Эспрессо</button>
        <button type="button" aria-pressed="false" data-filter="Иммерсия">Иммерсия</button>
        <button type="button" aria-pressed="false" data-filter="Молочный">Молочный</button>
        <button type="button" aria-pressed="false" data-filter="Избранное">Избранное</button>
      </div>
    </div>
  </section>

  <section class="catalog-section container" aria-labelledby="list-title">
    <h2 class="visually-hidden" id="list-title">Список рецептов</h2>
    <div class="result-count">
      <span id="result-count" aria-live="polite">06 рецептов</span>
      <label class="sort">
        <span class="visually-hidden">Сортировка</span>
        <select id="recipe-sort">
          <option value="popular">Сначала популярные</option>
          <option value="time">Сначала быстрые</option>
          <option value="title">По названию</option>
        </select>
        <svg class="icon" width="16" height="16" aria-hidden="true" focusable="false"><use href="#i-chevron"></use></svg>
      </label>
    </div>
    <ul class="recipe-grid catalog-grid" id="catalog-grid">
        <li>
          <article class="recipe-card" data-id="1" data-method="Пуровер" data-minutes="4">
            <div class="card-image">
              <picture><source type="image/webp" srcset="<?= Url::to("@web/img/v60-400.webp") ?> 400w, <?= Url::to("@web/img/v60-800.webp") ?> 800w, <?= Url::to("@web/img/v60-1200.webp") ?> 1200w" sizes="(min-width: 1200px) 400px, (min-width: 768px) 45vw, 92vw"><img src="img/v60-800.jpg" alt="Чашка кофе на тёмной каменной поверхности, вид сверху" width="800" height="533" loading="lazy" decoding="async"></picture>
              <span class="method-pill" style="background:#d8f35d">Пуровер</span>
              <button class="favorite-button" type="button" data-favorite="1" aria-pressed="false" aria-label="В избранное: V60: чистая классика"><svg class="icon" width="18" height="18" aria-hidden="true" focusable="false"><use href="#i-heart"></use></svg></button>
            </div>
            <div class="card-body">
              <p class="eyebrow">Цитрус · жасмин · мёд</p>
              <h3><a class="card-link" href="recipe?id=1">V60: чистая классика</a></h3>
              <div class="card-meta">
                <span><svg class="icon" width="16" height="16" aria-hidden="true" focusable="false"><use href="#i-clock"></use></svg> 4 мин</span>
                <span>Средне</span>
                <span class="card-arrow" aria-hidden="true"><svg class="icon" width="18" height="18" aria-hidden="true" focusable="false"><use href="#i-arrow"></use></svg></span>
              </div>
            </div>
          </article>
        </li>
        <li>
          <article class="recipe-card" data-id="2" data-method="Эспрессо" data-minutes="1">
            <div class="card-image">
              <picture><source type="image/webp" srcset="<?= Url::to("@web/img/espresso-400.webp") ?> 400w, <?= Url::to("@web/img/espresso-800.webp") ?> 800w, <?= Url::to("@web/img/espresso-1200.webp") ?> 1200w" sizes="(min-width: 1200px) 400px, (min-width: 768px) 45vw, 92vw"><img src="img/espresso-800.jpg" alt="Эспрессо вытекает из портафильтра" width="800" height="1199" loading="lazy" decoding="async"></picture>
              <span class="method-pill" style="background:#efa3a3">Эспрессо</span>
              <button class="favorite-button" type="button" data-favorite="2" aria-pressed="false" aria-label="В избранное: Эспрессо 1:2"><svg class="icon" width="18" height="18" aria-hidden="true" focusable="false"><use href="#i-heart"></use></svg></button>
            </div>
            <div class="card-body">
              <p class="eyebrow">Какао · вишня · карамель</p>
              <h3><a class="card-link" href="recipe?id=2">Эспрессо 1:2</a></h3>
              <div class="card-meta">
                <span><svg class="icon" width="16" height="16" aria-hidden="true" focusable="false"><use href="#i-clock"></use></svg> 1 мин</span>
                <span>Точно</span>
                <span class="card-arrow" aria-hidden="true"><svg class="icon" width="18" height="18" aria-hidden="true" focusable="false"><use href="#i-arrow"></use></svg></span>
              </div>
            </div>
          </article>
        </li>
        <li>
          <article class="recipe-card" data-id="3" data-method="Иммерсия" data-minutes="3">
            <div class="card-image">
              <picture><source type="image/webp" srcset="<?= Url::to("@web/img/aeropress-400.webp") ?> 400w, <?= Url::to("@web/img/aeropress-800.webp") ?> 800w, <?= Url::to("@web/img/aeropress-1200.webp") ?> 1200w" sizes="(min-width: 1200px) 400px, (min-width: 768px) 45vw, 92vw"><img src="img/aeropress-800.jpg" alt="Маленькая чашка кофе на белом фоне, вид сверху" width="800" height="1000" loading="lazy" decoding="async"></picture>
              <span class="method-pill" style="background:#afd6ed">Иммерсия</span>
              <button class="favorite-button" type="button" data-favorite="3" aria-pressed="false" aria-label="В избранное: Аэропресс: мягкий"><svg class="icon" width="18" height="18" aria-hidden="true" focusable="false"><use href="#i-heart"></use></svg></button>
            </div>
            <div class="card-body">
              <p class="eyebrow">Орех · яблоко · тростник</p>
              <h3><a class="card-link" href="recipe?id=3">Аэропресс: мягкий</a></h3>
              <div class="card-meta">
                <span><svg class="icon" width="16" height="16" aria-hidden="true" focusable="false"><use href="#i-clock"></use></svg> 3 мин</span>
                <span>Легко</span>
                <span class="card-arrow" aria-hidden="true"><svg class="icon" width="18" height="18" aria-hidden="true" focusable="false"><use href="#i-arrow"></use></svg></span>
              </div>
            </div>
          </article>
        </li>
        <li>
          <article class="recipe-card" data-id="4" data-method="Молочный" data-minutes="5">
            <div class="card-image">
              <picture><source type="image/webp" srcset="<?= Url::to("@web/img/cappuccino-400.webp") ?> 400w, <?= Url::to("@web/img/cappuccino-800.webp") ?> 800w, <?= Url::to("@web/img/cappuccino-1200.webp") ?> 1200w" sizes="(min-width: 1200px) 400px, (min-width: 768px) 45vw, 92vw"><img src="img/cappuccino-800.jpg" alt="Кофе наливается в белую чашку из кофемашины" width="800" height="1200" loading="lazy" decoding="async"></picture>
              <span class="method-pill" style="background:#f5cf77">Молочный</span>
              <button class="favorite-button" type="button" data-favorite="4" aria-pressed="false" aria-label="В избранное: Капучино 6 oz"><svg class="icon" width="18" height="18" aria-hidden="true" focusable="false"><use href="#i-heart"></use></svg></button>
            </div>
            <div class="card-body">
              <p class="eyebrow">Шоколад · фундук · сливки</p>
              <h3><a class="card-link" href="recipe?id=4">Капучино 6 oz</a></h3>
              <div class="card-meta">
                <span><svg class="icon" width="16" height="16" aria-hidden="true" focusable="false"><use href="#i-clock"></use></svg> 5 мин</span>
                <span>Средне</span>
                <span class="card-arrow" aria-hidden="true"><svg class="icon" width="18" height="18" aria-hidden="true" focusable="false"><use href="#i-arrow"></use></svg></span>
              </div>
            </div>
          </article>
        </li>
        <li>
          <article class="recipe-card" data-id="5" data-method="Капельный" data-minutes="7">
            <div class="card-image">
              <picture><source type="image/webp" srcset="<?= Url::to("@web/img/filter-400.webp") ?> 400w, <?= Url::to("@web/img/filter-800.webp") ?> 800w, <?= Url::to("@web/img/filter-1200.webp") ?> 1200w" sizes="(min-width: 1200px) 400px, (min-width: 768px) 45vw, 92vw"><img src="img/filter-800.jpg" alt="Эспрессо-машина, медный питчер и стеклянная чашка с кофе" width="800" height="1200" loading="lazy" decoding="async"></picture>
              <span class="method-pill" style="background:#c9b9ed">Капельный</span>
              <button class="favorite-button" type="button" data-favorite="5" aria-pressed="false" aria-label="В избранное: Фильтр на машине"><svg class="icon" width="18" height="18" aria-hidden="true" focusable="false"><use href="#i-heart"></use></svg></button>
            </div>
            <div class="card-body">
              <p class="eyebrow">Сухофрукты · какао · специи</p>
              <h3><a class="card-link" href="recipe?id=5">Фильтр на машине</a></h3>
              <div class="card-meta">
                <span><svg class="icon" width="16" height="16" aria-hidden="true" focusable="false"><use href="#i-clock"></use></svg> 7 мин</span>
                <span>Легко</span>
                <span class="card-arrow" aria-hidden="true"><svg class="icon" width="18" height="18" aria-hidden="true" focusable="false"><use href="#i-arrow"></use></svg></span>
              </div>
            </div>
          </article>
        </li>
        <li>
          <article class="recipe-card" data-id="6" data-method="Молочный" data-minutes="4">
            <div class="card-image">
              <picture><source type="image/webp" srcset="<?= Url::to("@web/img/hero-400.webp") ?> 400w, <?= Url::to("@web/img/hero-800.webp") ?> 800w, <?= Url::to("@web/img/hero-1200.webp") ?> 1200w" sizes="(min-width: 1200px) 400px, (min-width: 768px) 45vw, 92vw"><img src="img/hero-800.jpg" alt="Бариста переливает кофе из колбы в чашку" width="800" height="1200" loading="lazy" decoding="async"></picture>
              <span class="method-pill" style="background:#dcc5a9">Молочный</span>
              <button class="favorite-button" type="button" data-favorite="6" aria-pressed="false" aria-label="В избранное: Флэт уайт"><svg class="icon" width="18" height="18" aria-hidden="true" focusable="false"><use href="#i-heart"></use></svg></button>
            </div>
            <div class="card-body">
              <p class="eyebrow">Карамель · какао · ваниль</p>
              <h3><a class="card-link" href="recipe?id=6">Флэт уайт</a></h3>
              <div class="card-meta">
                <span><svg class="icon" width="16" height="16" aria-hidden="true" focusable="false"><use href="#i-clock"></use></svg> 4 мин</span>
                <span>Средне</span>
                <span class="card-arrow" aria-hidden="true"><svg class="icon" width="18" height="18" aria-hidden="true" focusable="false"><use href="#i-arrow"></use></svg></span>
              </div>
            </div>
          </article>
        </li>
    </ul>
    <div class="empty-state" id="empty-state" hidden>
      <svg class="icon" width="40" height="40" aria-hidden="true" focusable="false"><use href="#i-heart"></use></svg>
      <p class="empty-title" id="empty-title">Здесь пока пусто</p>
      <p id="empty-text">Добавьте рецепты в избранное — они появятся в этой подборке.</p>
      <button class="primary-button" type="button" id="empty-reset">Смотреть все</button>
    </div>
  </section>
</main>