/**
 * Crema — интерактив на чистом JavaScript.
 *
 * Модули запускаются только на тех страницах, где есть нужные элементы:
 *   initMenu      — мобильное меню (все страницы)
 *   initAuthState — «Войти / Выйти» в шапке (все страницы)
 *   initFavorites — избранное, хранится в localStorage (все страницы)
 *   initSlider    — слайдер «Рецепты недели» (index)
 *   initCatalog   — поиск, фильтры и сортировка (recipes)
 *   initRecipe    — страница рецепта из data.js (recipe)
 *   initMatcher   — тест «Подобрать вкус» (matcher)
 *   initAuthForms — валидация форм входа и регистрации (login, register)
 */
(function () {
  "use strict";

  /* ---------- Вспомогательные функции ---------- */

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const RECIPES = window.CREMA_RECIPES || [];
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  // localStorage может быть недоступен (приватный режим, запрет cookies) — не падаем
  const store = {
    get(key, fallback) {
      try {
        const raw = localStorage.getItem(key);
        return raw === null ? fallback : JSON.parse(raw);
      } catch (error) {
        return fallback;
      }
    },
    set(key, value) {
      try {
        localStorage.setItem(key, JSON.stringify(value));
      } catch (error) {
        /* ничего: просто не сохраняем */
      }
    },
    remove(key) {
      try {
        localStorage.removeItem(key);
      } catch (error) {
        /* ничего */
      }
    },
  };

  const icon = (name, size = 20) =>
    `<svg class="icon" width="${size}" height="${size}" aria-hidden="true" focusable="false"><use href="#i-${name}"></use></svg>`;

  const pad2 = (n) => String(n).padStart(2, "0");

  // «1 рецепт», «2 рецепта», «5 рецептов»
  function pluralize(n, one, few, many) {
    const mod10 = n % 10;
    const mod100 = n % 100;
    if (mod10 === 1 && mod100 !== 11) return one;
    if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return few;
    return many;
  }

  /* ---------- Уведомление (toast) ---------- */

  const TOAST_KEY = "crema.toast";
  let toastTimer;

  function showToast(message) {
    const toast = $("#toast");
    const text = $("#toast-text");
    if (!toast || !text) return;
    text.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
  }

  // Сообщение, которое нужно показать уже на следующей странице (после redirect)
  function queueToast(message) {
    try {
      sessionStorage.setItem(TOAST_KEY, message);
    } catch (error) {
      /* ничего */
    }
  }

  function flushQueuedToast() {
    try {
      const message = sessionStorage.getItem(TOAST_KEY);
      if (message) {
        sessionStorage.removeItem(TOAST_KEY);
        showToast(message);
      }
    } catch (error) {
      /* ничего */
    }
  }

  /* ---------- Мобильное меню ---------- */

  function initMenu() {
    const button = $(".menu-button");
    const nav = $("#site-nav");
    if (!button || !nav) return;

    const desktop = window.matchMedia("(min-width: 768px)");
    const isOpen = () => button.getAttribute("aria-expanded") === "true";

    function setOpen(open) {
      nav.classList.toggle("is-open", open);
      button.setAttribute("aria-expanded", String(open));
      button.setAttribute("aria-label", open ? "Закрыть меню" : "Открыть меню");
    }

    button.addEventListener("click", () => setOpen(!isOpen()));

    // Клик по ссылке или кнопке внутри меню закрывает его
    nav.addEventListener("click", (event) => {
      if (event.target.closest("a, button")) setOpen(false);
    });

    // Клик мимо шапки закрывает меню
    document.addEventListener("click", (event) => {
      if (isOpen() && !event.target.closest(".header")) setOpen(false);
    });

    // Escape закрывает меню и возвращает фокус на кнопку
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && isOpen()) {
        setOpen(false);
        button.focus();
      }
    });

    // При переходе на планшет/десктоп меню сбрасывается
    desktop.addEventListener("change", (event) => {
      if (event.matches) setOpen(false);
    });
  }

  /* ---------- «Авторизация» (демо, без сервера) ---------- */

  const USER_KEY = "user";
  const getUser = () => store.get(USER_KEY, null);

  function initAuthState() {
    const user = getUser();
    $$("[data-auth-login]").forEach((el) => {
      el.hidden = Boolean(user);
    });
    $$("[data-logout]").forEach((el) => {
      el.hidden = !user;
      el.addEventListener("click", () => {
        store.remove(USER_KEY);
        queueToast("Вы вышли из аккаунта");
        window.location.href = "login";
      });
    });
  }

  /* ---------- Избранное ---------- */

  const FAV_KEY = "crema.favorites";
  // В исходном макете по умолчанию в избранном лежит «Эспрессо 1:2»
  const getFavorites = () => store.get(FAV_KEY, [2]);

  function syncFavoriteButtons() {
    const favorites = getFavorites();
    $$("[data-favorite]").forEach((button) => {
      const active = favorites.includes(Number(button.dataset.favorite));
      button.classList.toggle("active", active);
      button.setAttribute("aria-pressed", String(active));
      const label = $("[data-favorite-label]", button);
      if (label) label.textContent = active ? "Сохранено" : "В избранное";
    });
  }

  function toggleFavorite(id) {
    const favorites = new Set(getFavorites());
    const adding = !favorites.has(id);
    if (adding) favorites.add(id);
    else favorites.delete(id);
    store.set(FAV_KEY, Array.from(favorites));
    showToast(adding ? "Рецепт добавлен в избранное" : "Рецепт удалён из избранного");
    syncFavoriteButtons();
    document.dispatchEvent(new CustomEvent("favorites:change"));
  }

  function initFavorites() {
    // Делегирование: работает и для карточек, созданных скриптом
    document.addEventListener("click", (event) => {
      const button = event.target.closest("[data-favorite]");
      if (!button) return;
      event.preventDefault();
      toggleFavorite(Number(button.dataset.favorite));
    });
    syncFavoriteButtons();
  }

  /* ---------- Слайдер «Рецепты недели» ---------- */

  function initSlider() {
    const root = $("[data-slider]");
    if (!root) return;

    const track = $("[data-slider-track]", root);
    const prev = $("[data-slider-prev]", root);
    const next = $("[data-slider-next]", root);
    const dotsBox = $("[data-slider-dots]", root);
    const slides = $$("[data-slider-track] > li", root);
    if (!track || !slides.length) return;

    let pages = 1;
    let page = 0;

    // Сколько карточек помещается сразу (1 / 2 / 3 — задаёт CSS)
    const perView = () => {
      const slideWidth = slides[0].getBoundingClientRect().width;
      return Math.max(1, Math.round(track.clientWidth / slideWidth));
    };
    const pageWidth = () => track.clientWidth + (parseFloat(getComputedStyle(track).columnGap) || 0);

    function goTo(index) {
      const clamped = Math.min(Math.max(index, 0), pages - 1);
      track.scrollTo({ left: clamped * pageWidth(), behavior: reduceMotion ? "auto" : "smooth" });
    }

    function buildDots() {
      pages = Math.ceil(slides.length / perView());
      dotsBox.innerHTML = "";
      for (let i = 0; i < pages; i += 1) {
        const dot = document.createElement("button");
        dot.type = "button";
        dot.className = "slider-dot";
        dot.setAttribute("aria-label", `Показать группу рецептов ${i + 1} из ${pages}`);
        dot.addEventListener("click", () => goTo(i));
        dotsBox.appendChild(dot);
      }
    }

    function update() {
      const maxScroll = track.scrollWidth - track.clientWidth;
      const atEnd = track.scrollLeft >= maxScroll - 4;
      page = atEnd ? pages - 1 : Math.round(track.scrollLeft / pageWidth());
      $$(".slider-dot", dotsBox).forEach((dot, i) => {
        const current = i === page;
        dot.classList.toggle("is-active", current);
        if (current) dot.setAttribute("aria-current", "true");
        else dot.removeAttribute("aria-current");
      });
      prev.disabled = track.scrollLeft <= 4;
      next.disabled = atEnd;
    }

    let ticking = false;
    track.addEventListener("scroll", () => {
      if (ticking) return;
      ticking = true;
      window.requestAnimationFrame(() => {
        update();
        ticking = false;
      });
    });

    prev.addEventListener("click", () => goTo(page - 1));
    next.addEventListener("click", () => goTo(page + 1));

    // Стрелки клавиатуры, когда фокус на ленте
    track.addEventListener("keydown", (event) => {
      if (event.key === "ArrowRight") {
        event.preventDefault();
        goTo(page + 1);
      } else if (event.key === "ArrowLeft") {
        event.preventDefault();
        goTo(page - 1);
      }
    });

    let resizeTimer;
    window.addEventListener("resize", () => {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(() => {
        buildDots();
        update();
      }, 120);
    });

    buildDots();
    update();
  }

  /* ---------- Каталог: поиск, фильтры, сортировка ---------- */

  function initCatalog() {
    const list = $("#catalog-grid");
    if (!list) return;

    const items = $$("li", list);
    const search = $("#recipe-search");
    const sort = $("#recipe-sort");
    const filterButtons = $$("[data-filter]");
    const count = $("#result-count");
    const empty = $("#empty-state");
    const emptyTitle = $("#empty-title");
    const emptyText = $("#empty-text");
    const emptyReset = $("#empty-reset");

    const state = { filter: "Все", query: "", sort: "popular" };

    // Данные карточки берём прямо из разметки
    const info = items.map((li, index) => {
      const card = $(".recipe-card", li);
      return {
        li,
        index,
        id: Number(card.dataset.id),
        method: card.dataset.method,
        minutes: Number(card.dataset.minutes),
        title: $("h3", card).textContent.trim(),
        text: `${$("h3", card).textContent} ${$(".eyebrow", card).textContent}`.toLowerCase(),
      };
    });

    function matches(item) {
      const favorites = getFavorites();
      let okFilter = true;
      if (state.filter === "Избранное") okFilter = favorites.includes(item.id);
      else if (state.filter !== "Все") okFilter = item.method === state.filter;
      return okFilter && item.text.includes(state.query);
    }

    function sorted(arr) {
      const copy = arr.slice();
      if (state.sort === "time") copy.sort((a, b) => a.minutes - b.minutes || a.index - b.index);
      else if (state.sort === "title") copy.sort((a, b) => a.title.localeCompare(b.title, "ru"));
      else copy.sort((a, b) => a.index - b.index);
      return copy;
    }

    function render() {
      const visible = info.filter(matches);
      info.forEach((item) => {
        item.li.hidden = !visible.includes(item);
      });
      sorted(info).forEach((item) => list.appendChild(item.li));

      count.textContent = `${pad2(visible.length)} ${pluralize(visible.length, "рецепт", "рецепта", "рецептов")}`;
      filterButtons.forEach((button) => {
        const active = button.dataset.filter === state.filter;
        button.classList.toggle("active", active);
        button.setAttribute("aria-pressed", String(active));
      });

      const isEmpty = visible.length === 0;
      empty.hidden = !isEmpty;
      list.hidden = isEmpty;
      if (isEmpty) {
        const onlyFavorites = state.filter === "Избранное" && !state.query;
        emptyTitle.textContent = onlyFavorites ? "Здесь пока пусто" : "Ничего не найдено";
        emptyText.textContent = onlyFavorites
          ? "Добавьте рецепты в избранное — они появятся в этой подборке."
          : "Попробуйте изменить запрос или выбрать другой способ.";
        emptyReset.textContent = onlyFavorites ? "Смотреть все" : "Сбросить фильтры";
      }
    }

    filterButtons.forEach((button) => {
      button.addEventListener("click", () => {
        state.filter = button.dataset.filter;
        render();
      });
    });
    search.addEventListener("input", () => {
      state.query = search.value.trim().toLowerCase();
      render();
    });
    sort.addEventListener("change", () => {
      state.sort = sort.value;
      render();
    });
    emptyReset.addEventListener("click", () => {
      state.filter = "Все";
      state.query = "";
      search.value = "";
      render();
    });
    document.addEventListener("favorites:change", () => {
      if (state.filter === "Избранное") render();
    });

    // Ссылки с главной: recipes?method=Пуровер
    const preset = new URLSearchParams(window.location.search).get("method");
    if (preset && filterButtons.some((button) => button.dataset.filter === preset)) {
      state.filter = preset;
    }

    render();
  }

  /* ---------- HTML карточки рецепта (для динамических вставок) ---------- */

  function cardHTML(recipe) {
    const [w, h] = recipe.imgSize;
    return `
      <article class="recipe-card" data-id="${recipe.id}">
        <div class="card-image">
          <picture>
            <source type="image/webp" srcset="img/${recipe.img}-400.webp 400w, img/${recipe.img}-800.webp 800w, img/${recipe.img}-1200.webp 1200w" sizes="(min-width: 768px) 360px, 92vw">
            <img src="img/${recipe.img}-800.jpg" alt="${recipe.alt}" width="${w}" height="${h}" loading="lazy" decoding="async">
          </picture>
          <span class="method-pill" style="background:${recipe.color}">${recipe.method}</span>
          <button class="favorite-button" type="button" data-favorite="${recipe.id}" aria-pressed="false" aria-label="В избранное: ${recipe.title}">${icon("heart", 18)}</button>
        </div>
        <div class="card-body">
          <p class="eyebrow">${recipe.notes}</p>
          <h3><a class="card-link" href="recipe?id=${recipe.id}">${recipe.title}</a></h3>
          <div class="card-meta">
            <span>${icon("clock", 16)} ${recipe.time}</span>
            <span>${recipe.level}</span>
            <span class="card-arrow" aria-hidden="true">${icon("arrow", 18)}</span>
          </div>
        </div>
      </article>`;
  }

  /* ---------- Страница рецепта ---------- */

  function initRecipe() {
    const root = $("#recipe-root");
    if (!root) return;

    const params = new URLSearchParams(window.location.search);
    const rawId = params.get("id");
    const recipe = rawId === null ? RECIPES[0] : RECIPES.find((item) => item.id === Number(rawId));

    if (!recipe) {
      document.title = "Crema";
      root.innerHTML = `
        <section class="page-heading container">
          <h1>Рецепт<br><em>не найден</em></h1>
          <p>Возможно, ссылка устарела. Загляните в каталог — там все доступные рецепты.</p>
          <a class="primary-button not-found-button" href="recipes">Смотреть рецепты ${icon("arrow")}</a>
        </section>`;
      return;
    }

    document.title = `Crema`;
    const description = $('meta[name="description"]');
    if (description) description.setAttribute("content", `${recipe.title}: ${recipe.description}`);

    const [w, h] = recipe.imgSize;
    const noteColors = ["#d8f35d", "#efa3a3", "#afd6ed"];
    const notes = recipe.notes
      .split(" · ")
      .map((note, i) => `<li style="--note-color:${noteColors[i % noteColors.length]}">${note}</li>`)
      .join("");
    const equipment = recipe.equipment
      .map((item, i) => `<li class="equipment-item"><span>${pad2(i + 1)}</span>${item}${icon("check", 18)}</li>`)
      .join("");
    const steps = recipe.steps
      .map(
        ([title, text], i) => `
        <li>
          <label class="step">
            <input class="step-check" type="checkbox">
            <span class="step-number"><span class="step-num">${pad2(i + 1)}</span>${icon("check", 20)}</span>
            <span class="step-text"><span class="step-title">${title}</span><span class="step-desc">${text}</span></span>
          </label>
        </li>`
      )
      .join("");

    root.innerHTML = `
      <nav class="breadcrumbs container" aria-label="Навигационная цепочка">
        <ol>
          <li><a href="recipes">Рецепты</a></li>
          <li aria-current="page">${recipe.method}</li>
        </ol>
      </nav>

      <section class="detail-hero container" aria-labelledby="recipe-title">
        <div class="detail-image">
          <picture>
            <source type="image/webp" srcset="img/${recipe.img}-400.webp 400w, img/${recipe.img}-800.webp 800w, img/${recipe.img}-1200.webp 1200w" sizes="(min-width: 1200px) 560px, (min-width: 768px) 45vw, 92vw">
            <img src="img/${recipe.img}-800.jpg" alt="${recipe.alt}" width="${w}" height="${h}" fetchpriority="high" decoding="async">
          </picture>
          <span class="detail-index" aria-hidden="true">${pad2(recipe.id)}</span>
        </div>
        <div class="detail-copy">
          <p class="eyebrow">${recipe.method} · ${recipe.roast}</p>
          <h1 id="recipe-title">${recipe.title}</h1>
          <p class="detail-lead">${recipe.description}</p>
          <ul class="flavor-notes" aria-label="Вкусовые ноты">${notes}</ul>
          <div class="detail-actions">
            <a class="primary-button" href="#steps">Начать готовить ${icon("arrow")}</a>
            <button class="save-button" type="button" data-favorite="${recipe.id}" aria-pressed="false">
              ${icon("heart")}<span data-favorite-label>В избранное</span>
            </button>
          </div>
          <ul class="recipe-facts" aria-label="Пропорции">
            <li>${icon("bean")}<span>Кофе<strong>${recipe.facts.coffee}</strong></span></li>
            <li>${icon("thermometer")}<span>Вода<strong>${recipe.facts.water}</strong></span></li>
            <li>${icon("clock")}<span>Время<strong>${recipe.facts.time}</strong></span></li>
          </ul>
        </div>
      </section>

      <section class="instructions" id="steps" aria-labelledby="steps-title">
        <div class="instructions-inner container">
          <div class="equipment">
            <p class="eyebrow">Что понадобится</p>
            <h2>Оборудование</h2>
            <ul>${equipment}</ul>
            <aside class="tip">
              <b>Совет</b>
              <p>${recipe.tip}</p>
            </aside>
          </div>
          <div class="steps-block">
            <p class="eyebrow">Пошаговый рецепт</p>
            <h2 id="steps-title">Завариваем</h2>
            <ol class="steps-list">${steps}</ol>
          </div>
        </div>
      </section>`;

    syncFavoriteButtons();
  }

  /* ---------- Тест «Подобрать вкус» ---------- */

  // Профили вкуса для каждого рецепта (id совпадает с data.js)
  const PROFILES = [
    { id: 1, acidity: 88, body: 28, sweetness: 62, milk: false, minutes: 5 },
    { id: 2, acidity: 42, body: 92, sweetness: 58, milk: false, minutes: 2 },
    { id: 3, acidity: 34, body: 54, sweetness: 76, milk: false, minutes: 4 },
    { id: 4, acidity: 18, body: 72, sweetness: 92, milk: true, minutes: 5 },
    { id: 5, acidity: 30, body: 62, sweetness: 66, milk: false, minutes: 8 },
    { id: 6, acidity: 14, body: 84, sweetness: 86, milk: true, minutes: 5 },
  ];

  function calculateMatch(answers) {
    const desiredBody =
      answers.mood === "Бодро и насыщенно" ? 90 : answers.mood === "Мягко и уютно" ? 65 : 30;
    const desiredSweetness =
      answers.mood === "Мягко и уютно" || answers.format === "С молоком" ? 88 : 62;
    const effortMinutes = answers.effort === "До 2 минут" ? 2 : answers.effort === "5 минут" ? 5 : 9;
    const wantsMilk = answers.format === "С молоком";

    const ranked = PROFILES.map((profile) => {
      const formatPenalty =
        answers.format === "По-разному" ? 0 : profile.milk === wantsMilk ? 0 : 65;
      const effortPenalty = Math.abs(profile.minutes - effortMinutes) * 5;
      const score =
        Math.abs(profile.acidity - answers.acidity) * 1.2 +
        Math.abs(profile.body - desiredBody) +
        Math.abs(profile.sweetness - desiredSweetness) * 0.65 +
        formatPenalty +
        effortPenalty;
      return Object.assign({}, profile, { score });
    }).sort((a, b) => a.score - b.score);

    const best = ranked[0];
    const recipe = RECIPES.find((item) => item.id === best.id) || RECIPES[0];
    const title =
      answers.format === "С молоком"
        ? "Мягкий гедонист"
        : answers.acidity > 68
          ? "Яркий исследователь"
          : desiredBody > 75
            ? "Смелый классик"
            : "Спокойный баланс";
    const origins =
      best.acidity > 65
        ? ["Эфиопии или Кении", "цитруса, цветов, ягод и чая"]
        : best.body > 75
          ? ["Бразилии или Колумбии", "какао, орехов и карамели"]
          : ["Гватемалы или Коста-Рики", "яблока, тростника и сухофруктов"];

    return {
      recipe,
      title,
      origins,
      acidity: Math.round((answers.acidity + best.acidity) / 2),
      sweetness: Math.round((desiredSweetness + best.sweetness) / 2),
      body: Math.round((desiredBody + best.body) / 2),
    };
  }

  function initMatcher() {
    const form = $("#matcher-form");
    const formSection = $("#matcher-start");
    const resultSection = $("#matcher-result");
    if (!form || !formSection || !resultSection) return;

    const range = $("#acidity");
    const setRange = () => form.style.setProperty("--range", `${range.value}%`);
    range.addEventListener("input", setRange);
    setRange();

    function readAnswers() {
      const data = new FormData(form);
      return {
        mood: data.get("mood"),
        format: data.get("format"),
        effort: data.get("effort"),
        acidity: Number(data.get("acidity")),
      };
    }

    function showResult(match) {
      const [first, ...rest] = match.title.split(" ");
      const bars = [
        ["Кислотность", match.acidity],
        ["Сладость", match.sweetness],
        ["Плотность", match.body],
      ]
        .map(
          ([label, value]) => `
          <li>
            <span>${label}<b>${value}%</b></span>
            <i><em style="width:${value}%"></em></i>
          </li>`
        )
        .join("");

      resultSection.innerHTML = `
        <div class="match-result">
          <div class="result-copy">
            <p class="eyebrow">Ваш вкусовой профиль</p>
            <h1 id="result-title" tabindex="-1">${first}<br><em>${rest.join(" ")}</em></h1>
            <p>Результат рассчитан по кислотности, плотности, формату напитка и времени, которое вы готовы уделить приготовлению.</p>
            <ul class="profile-bars">${bars}</ul>
            <button class="secondary-button" type="button" id="match-reset">Изменить ответы</button>
          </div>
          <div class="result-recipe">
            <p class="result-label">Ваш рецепт</p>
            ${cardHTML(match.recipe)}
          </div>
        </div>
        <aside class="result-note">
          ${icon("bean", 32)}
          <p><b>Ищите зерно из ${match.origins[0]}</b><span>с нотами ${match.origins[1]}.</span></p>
        </aside>`;

      formSection.hidden = true;
      resultSection.hidden = false;
      syncFavoriteButtons();
      window.scrollTo({ top: 0, behavior: reduceMotion ? "auto" : "smooth" });
      $("#result-title").focus({ preventScroll: true });

      $("#match-reset").addEventListener("click", () => {
        resultSection.hidden = true;
        formSection.hidden = false;
        window.scrollTo({ top: 0, behavior: reduceMotion ? "auto" : "smooth" });
      });
    }

    form.addEventListener("submit", (event) => {
      event.preventDefault();
      showResult(calculateMatch(readAnswers()));
    });
  }

  /* ---------- Формы входа и регистрации ---------- */

  const NAME_WORD = "[A-Za-zА-Яа-яЁё][A-Za-zА-Яа-яЁё'’-]+";
  const RE_FULL_NAME = new RegExp(`^${NAME_WORD}(\\s+${NAME_WORD}){1,2}$`);
  const RE_LOGIN = /^[A-Za-z0-9._-]{3,20}$/;
  const RE_EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  // Приводит ввод к виду «+7 999 000-00-00»
  function formatPhone(value) {
    let digits = value.replace(/\D/g, "");
    if (!digits) return "";
    if (digits[0] === "8") digits = `7${digits.slice(1)}`;
    else if (digits[0] !== "7") digits = `7${digits}`;
    digits = digits.slice(0, 11);
    const p = [digits.slice(1, 4), digits.slice(4, 7), digits.slice(7, 9), digits.slice(9, 11)];
    let out = "+7";
    if (p[0]) out += ` ${p[0]}`;
    if (p[1]) out += ` ${p[1]}`;
    if (p[2]) out += `-${p[2]}`;
    if (p[3]) out += `-${p[3]}`;
    return out;
  }

  // Правила: функция возвращает текст ошибки или пустую строку
  const RULES = {
    fullName(value) {
      if (!value.trim()) return "Введите фамилию и имя";
      return RE_FULL_NAME.test(value.trim())
        ? ""
        : "Укажите фамилию и имя (можно с отчеством) буквами, без цифр";
    },
    login(value, form) {
      if (!value.trim()) return "Введите логин";
      if (form.dataset.mode === "login") return "";
      return RE_LOGIN.test(value.trim())
        ? ""
        : "От 3 до 20 символов: латинские буквы, цифры, точка, дефис или подчёркивание";
    },
    phone(value) {
      if (!value.trim()) return "Введите номер телефона";
      return value.replace(/\D/g, "").length === 11 ? "" : "Номер должен содержать 11 цифр, например +7 999 000-00-00";
    },
    email(value) {
      if (!value.trim()) return "Введите email";
      return RE_EMAIL.test(value.trim()) ? "" : "Проверьте email — нужен адрес вида name@example.com";
    },
    password(value) {
      if (!value) return "Введите пароль";
      return value.length >= 6 ? "" : "Пароль — не менее 6 символов";
    },
    consent(_value, _form, input) {
      return input.checked ? "" : "Необходимо согласие с правилами и политикой";
    },
  };

  function initAuthForms() {
    $$("form[data-auth-form]").forEach((form) => {
      const fields = $$("[data-rule]", form);

      function validate(input) {
        const rule = RULES[input.dataset.rule];
        const message = rule(input.value, form, input);
        const error = document.getElementById(input.getAttribute("aria-describedby"));
        input.setAttribute("aria-invalid", message ? "true" : "false");
        input.classList.toggle("is-invalid", Boolean(message));
        if (error) {
          error.textContent = message;
          error.hidden = !message;
        }
        return !message;
      }

      fields.forEach((input) => {
        // Маска телефона
        if (input.dataset.rule === "phone") {
          input.addEventListener("input", () => {
            input.value = formatPhone(input.value);
          });
        }
        // Ошибку показываем после первого ухода с поля, затем проверяем на лету
        input.addEventListener("blur", () => {
          input.dataset.touched = "true";
          validate(input);
        });
        const liveEvent = input.type === "checkbox" ? "change" : "input";
        input.addEventListener(liveEvent, () => {
          if (input.dataset.touched === "true" || input.type === "checkbox") validate(input);
        });
      });

      form.addEventListener("submit", (event) => {
        event.preventDefault();
        let firstInvalid = null;
        fields.forEach((input) => {
          input.dataset.touched = "true";
          if (!validate(input) && !firstInvalid) firstInvalid = input;
        });
        if (firstInvalid) {
          firstInvalid.focus();
          return;
        }

        const nameInput = $('[data-rule="fullName"]', form);
        const loginInput = $('[data-rule="login"]', form);
        const name = (nameInput && nameInput.value.trim()) || loginInput.value.trim() || "Гость";
        // Пароль нигде не сохраняем: сервера нет, это демонстрация интерфейса
        store.set(USER_KEY, name);
        queueToast(`Добро пожаловать, ${name}`);
        window.location.href = "index";
      });

      const forgot = $("[data-forgot]", form);
      if (forgot) {
        forgot.addEventListener("click", () => showToast("Восстановление пароля пока недоступно"));
      }
    });
  }

  /* ---------- Запуск ---------- */

  function init() {
    const year = $("[data-year]");
    if (year) year.textContent = String(new Date().getFullYear());

    initMenu();
    initAuthState();
    initFavorites();
    initSlider();
    initCatalog();
    initRecipe();
    initMatcher();
    initAuthForms();
    flushQueuedToast();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
